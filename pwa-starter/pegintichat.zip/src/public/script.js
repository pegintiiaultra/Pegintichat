// Gestion du chat PEGINTICHAT V3

const chatForm = document.getElementById('chat-form');
const chatInput = document.getElementById('chat-input');
const wounanetInput = document.getElementById('wounanet-input');
const chatMessages = document.getElementById('chat-messages');
const wounanetBtn = document.getElementById('wounanet-btn');

function escapeHTML(str) {
  return String(str)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function formatMarkdown(text) {
  if (!text) return '';
  let html = escapeHTML(text);
  // **gras**
  html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  // *italique*
  html = html.replace(/\*(.*?)\*/g, '<em>$1</em>');
  // [texte](url)
  html = html.replace(/\[(.*?)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener" style="color:#00F3FF; font-weight:bold; text-decoration:underline;">$1 ↗</a>');
  // URLs autonomes
  html = html.replace(/(^|[^"'])((https?:\/\/[^\s<]+))/g, '$1<a href="$2" target="_blank" rel="noopener" style="color:#00F3FF; text-decoration:underline;">$2 ↗</a>');
  // Saut de ligne
  html = html.replace(/\n/g, '<br>');
  return html;
}

// Fonction pour ajouter un message dans le chat
function addMessage(sender, text) {
  const msg = document.createElement('div');
  msg.className = sender === 'user' ? 'user-message' : 'bot-message';
  msg.innerHTML = formatMarkdown(text);
  chatMessages.appendChild(msg);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Envoi du message utilisateur (Vitrine Publique - Bouton Jaune)
if (chatForm) {
  chatForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const text = chatInput.value.trim();
    if (!text) return;

    addMessage('user', text);
    chatInput.value = '';

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sujet: text })
      });

      const data = await res.json();
      let content = '';

      if (data.narration) {
        content = typeof data.narration === 'string' ? data.narration : data.narration;
      } else if (data.text) {
        content = data.text;
      } else if (data.reponse) {
        content = typeof data.reponse === 'string' ? data.reponse : [data.reponse, data.developpement, data.conclusion].filter(Boolean).join('\n\n');
      }

      addMessage('bot', content || 'Analyse doctrinale disponible.');
    } catch (err) {
      addMessage('bot', '⚠️ Erreur serveur : ' + err.message);
    }
  });
}

// Action du bouton Wounanet (Espace Recherche Wounanet - Bouton Vert)
async function executerRechercheWounanet() {
  const sujet = (wounanetInput ? wounanetInput.value : '').trim() || (chatInput ? chatInput.value : '').trim();
  if (!sujet) {
    addMessage('bot', '🌍 **Matrice Wounanet** : Saisissez un sujet d\'actualité dans l\'espace de recherche Wounanet (ex: *Géopolitique*, *Économie*, *Transition Énergétique*), puis cliquez sur le bouton vert Wounanet.');
    return;
  }

  addMessage('user', '🌍 Exploration Wounanet : ' + sujet);
  if (wounanetInput) wounanetInput.value = '';

  try {
    const res = await fetch('/api/wounanet', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sujet })
    });

    const data = await res.json();
    let content = data.text || '';
    
    if (!content && data.articles && Array.isArray(data.articles)) {
      content = `🌍 **Revue Wounanet — ${sujet}**\n\n` + data.articles.map((a, i) => `📌 **${i + 1}. ${a.title}** *(Source: ${a.source || 'Presse'})*\n🔗 [Consulter le rapport](${a.link})`).join('\n\n');
    }

    addMessage('bot', content || 'Synthèse Wounanet effectuée avec succès.');
  } catch (err) {
    addMessage('bot', '⚠️ Erreur Wounanet : ' + err.message);
  }
}

if (wounanetBtn) {
  wounanetBtn.addEventListener('click', executerRechercheWounanet);
}

if (wounanetInput) {
  wounanetInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      executerRechercheWounanet();
    }
  });
}


