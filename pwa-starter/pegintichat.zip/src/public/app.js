const responseDiv = document.getElementById('response');
const wounanetResponse = document.getElementById('wounanetResponse');
const chatOverlay = document.getElementById('chatOverlay');
const chatFeed = document.getElementById('chatFeed');

function escapeHTML(str) {
  return String(str)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function renderResponse(data) {
  // Fallback si le backend renvoie une chaîne brute
  if (typeof data === 'string') {
    return `<div class="answer">${escapeHTML(data)}</div>`;
  }

  const reponse = data.narration?.reponse || data.texte || '';
  const developpement = data.narration?.developpement || '';
  const conclusion = data.narration?.conclusion || '';

  return `
    <div class="answer">${escapeHTML(reponse)}</div>
    <div class="develop">${escapeHTML(developpement)}</div>
    <div class="conclusion">${escapeHTML(conclusion)}</div>
  `;
}

function addToFeed(question, data) {
  chatFeed.insertAdjacentHTML(
    'beforeend',
    `<div class="question">${escapeHTML(question)}</div>
     ${renderResponse(data)}`
  );
  chatFeed.scrollTop = chatFeed.scrollHeight;
}

async function send() {
  const input = document.getElementById('msg');
  const sujet = input.value.trim();
  if (!sujet) return;

  responseDiv.innerHTML = '🧠 PEGINTI analyse...';

  try {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sujet })
    });

    const data = await res.json();
    responseDiv.innerHTML = renderResponse(data);
    addToFeed(sujet, data);
    input.value = '';
  } catch (err) {
    responseDiv.innerHTML = '❌ Erreur serveur: ' + escapeHTML(err.message);
    console.error(err);
  }
}

function formatMarkdownWounanet(text) {
  if (!text) return '';
  let html = escapeHTML(text);
  html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  html = html.replace(/\*(.*?)\*/g, '<em>$1</em>');
  html = html.replace(/\[(.*?)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener" style="color:#00F3FF; font-weight:bold; text-decoration:underline;">$1 ↗</a>');
  html = html.replace(/(^|[^"'])((https?:\/\/[^\s<]+))/g, '$1<a href="$2" target="_blank" rel="noopener" style="color:#00F3FF; text-decoration:underline;">$2 ↗</a>');
  html = html.replace(/\n/g, '<br>');
  return html;
}

async function runWounanet() {
  const sujetInput = document.getElementById('wounanetMsg');
  const sujet = sujetInput ? sujetInput.value.trim() : '';

  if (!sujet) {
    wounanetResponse.innerHTML = '<div style="color: var(--gold-primary); padding: 10px;">🌍 Veuillez saisir un sujet d\'actualité ou un mot-clé avant de lancer la recherche Wounanet.</div>';
    return;
  }

  wounanetResponse.innerHTML = '🌍 Exploration des dépêches Wounanet en cours...';

  try {
    const res = await fetch('/api/wounanet?sujet=' + encodeURIComponent(sujet));
    const data = await res.json();

    let output = '';
    if (data.text) {
      output = `<div style="background: rgba(15,23,42,0.85); border: 1px solid var(--gold-primary); padding: 15px; border-radius: 10px; color: #f8fafc; line-height: 1.5;">${formatMarkdownWounanet(data.text)}</div>`;
    } else if (data.articles && Array.isArray(data.articles)) {
      output = `
        <div style="background: rgba(15,23,42,0.85); border: 1px solid var(--gold-primary); padding: 15px; border-radius: 10px;">
          <h4 style="color: var(--gold-primary); margin-top: 0;">🌍 Revue de Presse Wounanet : ${escapeHTML(sujet)}</h4>
          ${data.articles.map(a => `
            <div style="margin-bottom: 12px; padding: 10px; background: rgba(255,255,255,0.03); border-radius: 8px;">
              <strong style="color: var(--cyan-accent);">${escapeHTML(a.title)}</strong><br>
              <small style="color: #94a3b8;">Source : ${escapeHTML(a.source || 'Presse')}</small><br>
              <a href="${escapeHTML(a.link)}" target="_blank" rel="noopener" style="color: #00FF66; font-size: 0.85rem;">Consulter l'article ↗</a>
            </div>
          `).join('')}
        </div>
      `;
    } else {
      output = `<div style="color: #cbd5e1;">Synthèse Wounanet pour "${escapeHTML(sujet)}" effectuée.</div>`;
    }

    wounanetResponse.innerHTML = output;
  } catch (err) {
    wounanetResponse.innerHTML = '❌ Erreur WOUNANET: ' + escapeHTML(err.message);
    console.error(err);
  }
}

// Gestion des événements
document.getElementById('sendBtn').onclick = send;
document.getElementById('wounanetBtn').onclick = runWounanet;

document.getElementById('msg').addEventListener('keydown', e => {
  if (e.key === 'Enter') send();
});

document.getElementById('wounanetMsg').addEventListener('keydown', e => {
  if (e.key === 'Enter') runWounanet();
});

document.getElementById('chatOpen').onclick = () => {
  chatOverlay.setAttribute('aria-hidden', 'false');
};

document.getElementById('chatClose').onclick = () => {
  chatOverlay.setAttribute('aria-hidden', 'true');
};

document.getElementById('refreshBtn').onclick = () => {
  location.reload();
};
