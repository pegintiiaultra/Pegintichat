const wounanetCore = require('../wounanet');

module.exports = {
  getActualites: async (sujet) => {
    return wounanetCore.fetch(sujet);
  },
  search: async (sujet) => {
    return wounanetCore.fetch(sujet);
  }
};

