const axios = require('axios');

// Cache mémoire simple (clé = sujet)
let cache = {};

function formaterNarration(sujet, results) {
  if (!results || results.length === 0) {
    return `🌍 **Analyse Wounanet — « ${sujet} »**\n\nEn l'absence de dépêches directes instantanées sur ce terme, le réseau Wounanet s'appuie sur le référentiel doctrinal PEGINTI pour analyser les enjeux fondamentaux de « ${sujet} » avec discernement et hauteur d'esprit.`;
  }

  let text = `🌍 **Revue de Presse & Synthèse Wounanet — « ${sujet} »**\n\n`;
  text += `L'analyse des dépêches récentes récoltées par le réseau Wounanet apporte un éclairage factuel et stratégique sur « ${sujet} » :\n\n`;

  results.forEach((a, idx) => {
    const title = a.title || 'Dépêche d\'actualité';
    const source = a.source_id ? a.source_id.toUpperCase() : 'PRESSE';
    const link = a.link || '';
    const desc = a.description ? a.description.replace(/<[^>]*>/g, '').trim() : '';

    text += `📌 **${idx + 1}. ${title}**\n`;
    text += `   *Source : ${source}*\n`;
    if (desc) {
      text += `   ${desc.slice(0, 180)}...\n`;
    }
    if (link) {
      text += `   🔗 [Consulter la source originale sur ${source}](${link})\n`;
    }
    text += `\n`;
  });

  text += `🧠 **Perspective Souveraine PEGINTI :**\nCes faits contemporains rappellent la nécessité d'une lecture souveraine, éthique et éclairée, préservant l'autonomie de notre pensée et la recherche d'une paix durable.`;
  return text;
}

async function fetch(sujet) {
  const sujetClean = String(sujet || 'Actualités').trim();
  const apiKey = process.env.WOUNANET_API_KEY || process.env.NEWSDATA_APIKEY || process.env.NEWSDATA_API_KEY;

  if (!apiKey) {
    return {
      type: "doctrinal-fallback",
      source: "Wounanet Souverain",
      text: `🌍 **Analyse Wounanet — « ${sujetClean} »**\n\nLa matrice Wounanet examine « ${sujetClean} » à travers le prisme de la souveraineté intellectuelle, de la résilience et du progrès culturel.`,
      query: sujetClean,
      articles: []
    };
  }

  // Vérifier le cache (10 minutes)
  if (cache[sujetClean] && (Date.now() - cache[sujetClean].timestamp < 10 * 60 * 1000)) {
    return {
      ...cache[sujetClean].data,
      cached: true
    };
  }

  const url = `https://newsdata.io/api/1/news?apikey=${apiKey}&q=${encodeURIComponent(sujetClean)}&language=fr&size=5`;

  try {
    const response = await axios.get(url, { timeout: 8000 });
    const results = response.data?.results || [];
    
    if (results.length > 0) {
      const articlesFormatted = results.map(a => ({
        title: a.title,
        link: a.link,
        source: a.source_id ? a.source_id.toUpperCase() : 'PRESSE',
        description: a.description || ''
      }));

      const result = {
        type: "external-newsdata",
        source: "Wounanet News",
        text: formaterNarration(sujetClean, results),
        query: sujetClean,
        articles: articlesFormatted,
        timestamp: new Date().toISOString()
      };

      cache[sujetClean] = { data: result, timestamp: Date.now() };
      return result;
    } else {
      return {
        type: "synthèse-analytique",
        source: "Wounanet",
        text: formaterNarration(sujetClean, []),
        query: sujetClean,
        articles: []
      };
    }
  } catch (e) {
    return {
      type: "synthèse-analytique",
      source: "Wounanet",
      text: `🌍 **Analyse Wounanet — « ${sujetClean} »**\n\nLes systèmes de dépêches sont actuellement en cours de mise à jour. PEGINTI livre une synthèse basée sur la matrice de réflexion doctrinale.`,
      query: sujetClean,
      articles: []
    };
  }
}

async function searchDirect(q) {
  return fetch(q);
}

module.exports = { fetch, searchDirect };

