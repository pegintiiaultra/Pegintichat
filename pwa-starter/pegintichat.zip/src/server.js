'use strict';

require('dotenv').config();

const express = require('express');
const path = require('path');
const fs = require('fs');
const fsp = require('fs/promises');

const wounanet = require('./services/wounanet');
const matrice = require('./matrice/index.js');
const bip = require('./moteur/bip.js');

const VERSION = '3.0.0';
const PORT = process.env.PORT || 3000;

// Correction : public dans src/public
const PUBLIC_DIR = path.join(__dirname, 'public');
const DATA_DIR = path.join(__dirname, 'data');
const MEM_FILE = path.join(DATA_DIR, 'memoire.json');
const DOCTRINE_FILE = path.join(DATA_DIR, 'doctrine.json');

function ensureFile(file, initialContent) {
  if (!fs.existsSync(file)) fs.writeFileSync(file, initialContent, 'utf8');
}

function ensureStorage() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  ensureFile(MEM_FILE, '[]');
  ensureFile(DOCTRINE_FILE, '{}');
}

function readJson(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return fallback;
  }
}

function loadMemoire() {
  return readJson(MEM_FILE, []);
}

async function saveMemoire(entry) {
  const memoire = loadMemoire();
  memoire.push(entry);
  await fsp.writeFile(MEM_FILE, JSON.stringify(memoire, null, 2), 'utf8');
}

const app = express();

app.use(express.json());

// Routage dynamique par nom de domaine / sous-domaine (PEGINTICHAT.online)
app.use((req, res, next) => {
  const host = (req.headers.host || '').toLowerCase();
  if (host.includes('premium.pegintichat.online') || host.includes('ultra.pegintichat.online')) {
    if (req.path === '/') {
      return res.sendFile(path.join(PUBLIC_DIR, 'premium.html'));
    }
  }
  next();
});

app.use(express.static(PUBLIC_DIR));

// Endpoint d'information et configuration du domaine PEGINTICHAT.online
app.get('/api/domaine-config', (req, res) => {
  res.json({
    domaine_principal: 'PEGINTICHAT.online',
    statut_trafic: 'ACTIF ⚡',
    nom_concepteur: 'TOMO OMBEDE BARNABÉ BERTRAND (TOMTECH.INC)',
    routages: {
      site_public: 'https://pegintichat.online',
      vitrine_premium: 'https://premium.pegintichat.online',
      ultra_premium: 'https://ultra.pegintichat.online'
    },
    tunnel_paiement: {
      mtn_momoe: '+237 676867712 (TOMO OMBEDE BARNABÉ BERTRAND)',
      orange_money: '+237 691482453 (TOMO OMBEDE BARNABÉ BERTRAND)'
    },
    serveur_port: PORT,
    ssl_active: true
  });
});

app.get('/', (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
});

app.get('/status', (req, res) => {
  res.json({
    service: 'PEGINTICHAT',
    version: VERSION,
    status: 'ONLINE',
    uptime: process.uptime(),
    pid: process.pid
  });
});

app.get('/memoire', (req, res) => {
  res.json(loadMemoire());
});

app.get('/ping', (req, res) => {
  res.json({ status: 'ok', message: 'pong' });
});

// Vitrine Premium & Chat bo'oivini Router
const premiumRouter = require('./routes/premium.js');
app.use('/api/premium', premiumRouter);

app.get('/premium', (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, 'premium.html'));
});

// Chargement automatique du module identité
try {
  const identiteModule = require('./identite');
  if (identiteModule && identiteModule.route && identiteModule.handler) {
    const method = (identiteModule.method || 'get').toLowerCase();
    app[method](identiteModule.route, identiteModule.handler);
    app[method](`/api${identiteModule.route}`, identiteModule.handler);
  }
} catch (err) {
  console.warn("Module identite non chargé dans le serveur :", err.message);
}

app.get('/api/wounanet', async (req, res) => {
  try {
    const sujet = String(req.query.sujet || 'Afrique').trim();
    const result = await wounanet.search(sujet);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/wounanet', async (req, res) => {
  try {
    const sujet = String(req.body.sujet || req.body.q || 'Afrique').trim();
    const result = await wounanet.search(sujet);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/chat', async (req, res) => {
  try {
    const sujet = String(req.body.sujet || req.body.message || '').trim();
    if (!sujet) return res.status(400).json({ error: 'Sujet requis' });

    const moduleTrouve = bip.scan ? bip.scan(sujet) : null;
    const memoire = loadMemoire();
    const actualites = await wounanet.search(sujet);
    
    // Raisonnement narratif intégrant Wounanet + Doctrinal modules + Mémoire
    const logique = await matrice.raisonner(sujet, {
      module: moduleTrouve,
      memoire,
      actualites
    });

    const texteFinal = [
      logique?.reponse || '',
      logique?.developpement || '',
      logique?.conclusion || ''
    ].filter(Boolean).join('\n\n').trim();

    const entry = {
      sujet,
      narration: texteFinal,
      reponse: logique?.reponse || '',
      developpement: logique?.developpement || '',
      conclusion: logique?.conclusion || '',
      actualites,
      souveraine: true,
      timestamp: new Date().toISOString()
    };

    await saveMemoire(entry);
    res.json(entry);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.use((req, res) => res.status(404).json({ error: 'Route introuvable' }));

ensureStorage();
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 PEGINTICHAT V${VERSION} sur port ${PORT}`);
  console.log('🧠 CHAT : ACTIF');
  console.log('🌍 WOUNANET : ACTIF');
  console.log('💾 MEMOIRE : ACTIVE');
});
