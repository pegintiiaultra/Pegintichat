'use strict';

const fs = require('fs');
const path = require('path');

const MEMOIRE_FILE = path.join(__dirname, '..', 'data', 'memoire.json');
const MODULES_DIR = path.join(__dirname, '..', 'plugins');

function lireJson(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return fallback;
  }
}

function scannerModules(intention) {
  const sujet = String(intention?.sujet || intention?.original || '').toLowerCase();
  const hits = [];

  try {
    if (fs.existsSync(MODULES_DIR)) {
      const files = fs.readdirSync(MODULES_DIR);
      for (const file of files) {
        if (file.endsWith('.js')) {
          const filePath = path.join(MODULES_DIR, file);
          const key = file.replace('.js', '');
          try {
            delete require.cache[require.resolve(filePath)];
            const contenu = require(filePath);
            if (sujet.includes(key) || (contenu.categories && contenu.categories.some(c => sujet.includes(c)))) {
              hits.push({ key, file, contenu });
            }
          } catch {
            // Fichier ignorant
          }
        }
      }
    }
  } catch (err) {
    console.error("Erreur scannerModules:", err.message);
  }

  return hits;
}

function scan(sujetInput) {
  const sujet = String(sujetInput || '').trim();
  const q = sujet.toLowerCase();
  const matchedPlugins = [];
  const matchedDoctrineEntries = [];

  // 1. Chargement automatique et dynamique de tous les plugins doctrinaux
  try {
    if (fs.existsSync(MODULES_DIR)) {
      const files = fs.readdirSync(MODULES_DIR);
      for (const file of files) {
        if (file.endsWith('.js')) {
          const filePath = path.join(MODULES_DIR, file);
          try {
            delete require.cache[require.resolve(filePath)];
            const plugin = require(filePath);
            const nom = plugin.nom || file.replace('.js', '');
            
            let isMatch = q.includes(nom.toLowerCase());
            if (!isMatch && Array.isArray(plugin.categories)) {
              isMatch = plugin.categories.some(c => q.includes(c.toLowerCase()));
            }

            if (isMatch || nom === 'peginti') {
              let narration = null;
              if (typeof plugin.handle === 'function') {
                narration = plugin.handle({ sujet });
              } else if (typeof plugin === 'string') {
                narration = plugin;
              }
              matchedPlugins.push({ nom, plugin, narration });
            }
          } catch (e) {
            console.error(`Erreur chargement plugin ${file}:`, e.message);
          }
        }
      }
    }
  } catch (e) {
    console.error("Erreur lecture dossier plugins:", e.message);
  }

  // 2. Chargement automatique des fichiers de doctrine JSON
  const dbPaths = [
    path.join(__dirname, '..', 'data', 'doctrine.json'),
    path.join(__dirname, '..', 'db', 'doctrine.json')
  ];

  for (const dbPath of dbPaths) {
    const data = lireJson(dbPath, {});
    for (const [key, val] of Object.entries(data)) {
      const kLower = key.toLowerCase();
      if (q.includes(kLower) || kLower.split(' ').some(w => w.length > 3 && q.includes(w))) {
        matchedDoctrineEntries.push({ key, ...val });
      }
    }
  }

  return {
    sujet,
    plugins: matchedPlugins,
    doctrineDb: matchedDoctrineEntries,
    narration: matchedPlugins.map(p => p.narration).filter(Boolean).join('\n')
  };
}

function scannerMemoire(intention) {
  const memoire = lireJson(MEMOIRE_FILE, []);
  const sujet = String(intention?.sujet || intention?.original || '').toLowerCase();

  const matches = memoire.filter(entry => {
    const text = JSON.stringify(entry || {}).toLowerCase();
    return sujet && text.includes(sujet);
  });

  return {
    total: memoire.length,
    matches,
    resume: matches.length
      ? `Mémoire: ${matches.length} correspondance(s)`
      : 'Mémoire: aucune correspondance'
  };
}

async function collecteWounanet(sujet) {
  const texte = String(sujet || '').trim();

  return {
    source: 'wounanet',
    sujet: texte,
    resume: texte ? `Recherche Wounanet sur: ${texte}` : 'Recherche Wounanet vide',
    details: []
  };
}

async function rechercher(intention) {
  const modules = scannerModules(intention);
  const memoire = scannerMemoire(intention);
  const sujet = String(intention?.sujet || intention?.original || '').trim();

  let wounanet = null;

  if (!modules.length && !memoire.matches.length) {
    wounanet = await collecteWounanet(sujet);
  }

  return {
    modules,
    memoire,
    wounanet,
    resume: modules.length
      ? `Modules: ${modules.length} trouvé(s)`
      : memoire.matches.length
        ? memoire.resume
        : (wounanet?.resume || 'Aucune donnée utile')
  };
}

module.exports = {
  scan,
  scannerModules,
  scannerMemoire,
  collecteWounanet,
  rechercher
};
