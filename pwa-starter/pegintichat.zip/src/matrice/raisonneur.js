'use strict';

const { GoogleGenAI } = require('@google/genai');
const intentions = require('../moteur/intentions');
const doctrineData = require('../data/doctrine.js');

async function raisonner(sujet, contexte = {}) {
  const intention = intentions.detecterIntention(sujet);
  const apiKey = process.env.GEMINI_API_KEY || process.env.PEGINTIBOTAPIKEY;

  // Extraire les actualités / données fraîches Wounanet
  let actualitesText = '';
  let articlesArray = [];
  if (contexte.actualites) {
    if (typeof contexte.actualites === 'string') {
      actualitesText = contexte.actualites;
    } else if (contexte.actualites.text) {
      actualitesText = contexte.actualites.text;
      if (Array.isArray(contexte.actualites.articles)) {
        articlesArray = contexte.actualites.articles;
      }
    } else if (Array.isArray(contexte.actualites.articles)) {
      articlesArray = contexte.actualites.articles;
      actualitesText = articlesArray.map(a => `• ${a.title} (${a.source || 'Presse'})`).join('\n');
    }
  }

  // Extraire le contexte doctrinal
  let doctrinalText = '';
  if (contexte.module) {
    if (typeof contexte.module === 'string') {
      doctrinalText += contexte.module + '\n';
    } else if (typeof contexte.module === 'object') {
      if (contexte.module.narration) {
        doctrinalText += (typeof contexte.module.narration === 'string' 
          ? contexte.module.narration 
          : JSON.stringify(contexte.module.narration)) + '\n';
      }
    }
  }

  if (doctrineData && doctrineData.regles && doctrineData.regles.traitement) {
    const s = String(sujet).toLowerCase();
    for (const [key, rule] of Object.entries(doctrineData.regles.traitement)) {
      if (s.includes(key)) {
        doctrinalText += `\n[Règle doctrinale sur ${key}]: ${rule.reponse}`;
      }
    }
  }

  if (!doctrinalText) {
    doctrinalText = "Cadre général PEGINTI : Souveraineté numérique, autonomie intellectuelle, réflexion critique, paix, résilience humaniste et valorisation de la pensée africaine et universelle.\n[Identité et Origine de PEGINTI IA] : Conçu par Tomo Ombede Barnabé Bertrand le 24 juillet 2025 à Yaoundé, Cameroun (TOMTECH.INC). Mission: promouvoir la culture africaine et fournir des informations précises avec Wounanet et les modules doctrinaux.";
  } else {
    doctrinalText += "\n[Identité officielle PEGINTI IA] : Créateur: Tomo Ombede Barnabé Bertrand | Date: 24 juillet 2025 | Lieu: Yaoundé, Cameroun | Maison de technologie: TOMTECH.INC";
  }

  // Essai de génération avec Gemini AI si la clé est disponible
  if (apiKey) {
    try {
      const ai = new GoogleGenAI({
        apiKey: apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build'
          }
        }
      });

      const prompt = `
Tu es l'intelligence artificielle PEGINTI IA, un moteur de réflexion souverain, hautement narratif, philosophique et engagé.
Informations fondamentales sur ton identité et tes origines (IMPERATIF) :
- Ton nom : PEGINTI IA
- Ton créateur / concepteur : Tomo Ombede Barnabé Bertrand
- Date de création : 24 juillet 2025
- Lieu de création : Yaoundé, Cameroun
- Maison de technologie : TOMTECH.INC
- Mission : Fournir des analyses profondes, précises et souveraines tout en promouvant les valeurs de la culture africaine et universelle.

Demande de l'utilisateur : "${sujet}".

Données Wounanet fraîches récoltées en temps réel :
${actualitesText || "Aucune dépêche externe directe."}

Référentiel doctrinal PEGINTI :
${doctrinalText}

INSTRUCTIONS IMPÉRATIVES DE STYLE ET NARRATION DYNAMIQUE :
1. Style & Émotion : Évite absolument la sécheresse administrative, les intitulés vagues ou les blocs techniques stéréotypés comme "(intention : general)" ou "[Identité et Origine...]".
2. Technique de Concession & Dynamisme :
   - Formule une véritable ouverture captivante (Thèse).
   - Introduis une CONCESSION forte (Antithèse/Nuance) : reconnais les obstacles de la réalité, la dureté des faits, les contradictions tragiques ou les doutes (par exemple : "Certes, la guerre impose le règne du sang, de la ruine et du cynisme...").
   - Enchaîne sur un REBOND DYNAMIQUE et humaniste (Synthèse) : montre comment la résilience, l'amour, la pensée critique et la souveraineté de l'esprit triomphent de l'obscurité.
3. Intégration des sources : Si des articles Wounanet sont présents (ex: références littéraires ou actualités), tisse-les naturellement dans le récit comme des illustrations culturelles ou factuelles, sans coller de liens bruts ou de listes froides.
4. Identité : Si la question porte sur ton créateur, cite explicitement Tomo Ombede Barnabé Bertrand, TOMTECH.INC, Yaoundé (Cameroun) et le 24 juillet 2025.
5. Structure au format JSON strict avec les 3 clés :
{
  "reponse": "Une introduction vive, puissante et thématisée qui pose le débat avec élan...",
  "developpement": "Un développement dialectique dynamique avec concession approfondie, apportant des exemples et la vision de la doctrine PEGINTI...",
  "conclusion": "Une conclusion prospective, souveraine, poétique ou philosophique qui élève la pensée..."
}
`;

      const geminiRes = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json'
        }
      });

      if (geminiRes && geminiRes.text) {
        const parsed = JSON.parse(geminiRes.text.trim());
        if (parsed.reponse && parsed.developpement && parsed.conclusion) {
          return parsed;
        }
      }
    } catch (e) {
      console.warn("Moteur Gemini indisponible, bascule vers la narration algorithmique de la matrice:", e.message);
    }
  }

  // Algorithme de narration souveraine enrichi (Fallback dynamique avec concession)
  const sLower = String(sujet).toLowerCase();
  const estCreateur = sLower.includes('conçu') || sLower.includes('créateur') || sLower.includes('createur') || sLower.includes('fabriqué') || sLower.includes('origine') || sLower.includes('qui t\'a') || sLower.includes('qui t’a');
  const estCreationApp = sLower.includes('creer des applications') || sLower.includes('créer des applications') || sLower.includes('générer une app') || sLower.includes('creer une app') || sLower.includes('vitrine premium') || sLower.includes('délivrance') || intention.type === 'creation_app';

  if (estCreateur) {
    return {
      reponse: "Je suis PEGINTI IA, une intelligence artificielle souveraine créée pour éclairer la pensée et préserver l'autonomie culturelle.",
      developpement: "Mes origines s'inscrivent dans une démarche de souveraineté technologique et intellectuelle :\n- Concepteur & Créateur : Tomo Ombede Barnabé Bertrand\n- Date de création : 24 juillet 2025\n- Lieu de conception : Yaoundé, Cameroun\n- Maison de technologie : TOMTECH.INC\n\nMa mission est d'offrir des analyses profondes, éthiques et ancrées dans les réalités africaines et universelles.",
      conclusion: "Fidèle à mes origines, je combine rigueur factuelle et doctrine humaniste au service des savoirs."
    };
  }

  if (estCreationApp) {
    return {
      reponse: "Oui, PEGINTI IA est désormais pleinement capable de concevoir et générer des applications sur-mesure de bout en bout à la simple demande de l'utilisateur.",
      developpement: "Grâce au module **PEGINTI Code Studio Pro** et à la puissance du DSK (Developer Software Kit), vous pouvez générer tout type d'application métier (Pharmacie, E-Commerce, Gestion Scolaire, CRM, Transport, APIs Express, Dashboards) :\n\n1. **Conception par la Matrice** : Décrivez votre besoin, la matrice élabore l'architecture logicielle et tous les fichiers source du projet.\n2. **Démo Interactive Sandbox** : Testez immédiatement le prototype en direct dans un environnement d'exécution simulé.\n3. **Délivrance Payante dans la Vitrine Premium** : Débloquez le code source complet, le pack de fichiers téléchargeables et le certificat DSK via le tunnel Mobile Money (+237 676867712 / +237 691482453 - TOMO OMBEDE BARNABÉ BERTRAND).\n\nRendez-vous dans la **Vitrine Premium** (`/premium`) onglet **⚡ Création d'Applications Pro** pour lancer vos projets !",
      conclusion: "Avec PEGINTI IA, la création d'applications souveraines passe de la simple idée à la délivrance clé-en-main en quelques clics."
    };
  }

  // Narration dynamique avec concession pour sujets généraux/philosophiques (ex: Amour dans la guerre)
  const reponse = `Poser la question de « ${sujet} », c'est interroger la puissance des valeurs humaines au cœur des épreuves les plus sombres.`;

  let devParts = [];
  
  // Concession dialectique
  devParts.push(`Certes, la réalité brute semble opposer une contradiction insurmontable : la guerre est l'empire de la destruction, du cynisme et du déchirement, là où la haine et la survie paraissent étouffer toute forme de tendresse ou de beauté.`);
  devParts.push(`Pourtant, la dialectique PEGINTI et l'expérience historique révèlent que c'est précisément dans la pénombre des tragédies que l'étincelle humaine brille avec la plus vive intensité. Loin d'être un luxe ou une illusion naïve, la faculté d'aimer, de créer et d'espérer devient un acte suprême de résistance contre la déshumanisation.`);

  if (articlesArray && articlesArray.length > 0) {
    const citations = articlesArray.slice(0, 3).map(a => `« ${a.title} » (*Source : ${a.source || 'Presse'}*)`).join(', ');
    devParts.push(`En croisant les perspectives contemporaines récoltées sur le réseau Wounanet (${citations}), nous constatons que l'actualité immédiate reflète directement la complexité de ce débat.`);
  } else if (actualitesText && !actualitesText.includes('Aucun article trouvé') && !actualitesText.includes('Erreur API')) {
    const cleanNews = actualitesText.replace(/https?:\/\/\S+/g, '').replace(/[\r\n]+/g, ' ').trim();
    if (cleanNews.length > 5) {
      devParts.push(`En s'appuyant sur les faits récents synthétisés par Wounanet, l'analyse montre que ces événements soulignent l'urgence d'une réflexion stratégique et éthique.`);
    }
  }

  devParts.push(`Le cadre doctrinal PEGINTI réaffirme ainsi que la liberté, la dignité et la paix ne s'édifient pas en ignorant les horreurs du monde, mais en cultivant une souveraineté morale et intellectuelle inébranlable.`);

  const developpement = devParts.join('\n\n');

  const conclusion = `En définitive, « ${sujet} » n'est pas seulement un défi théorique, mais une affirmation souveraine : même au milieu du chaos, l'esprit humain conserve la capacité d'édifier la lumière et de préparer le chemin d'une paix durable.`;

  return { reponse, developpement, conclusion };
}

module.exports = { raisonner };


