'use strict';

const raisonneur = require('./raisonneur');

module.exports = {
  raisonner: async (sujet, contexte) => {
    return raisonneur.raisonner(sujet, contexte);
  }
};

